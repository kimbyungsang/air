from distutils.core import setup

setup(
    name = 'nester',
    version = '1.2.0',
    py_modules = ['nester'],
    author = 'bskim',
    author_email = 'bskim@gmail.com',
    url = 'bskim.com',
    description = 'A simple printer of nested lists'
    )
